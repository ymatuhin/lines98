import { createStore } from "shared/store";
// import { createStore, createEffect } from "effector";

import type { Coords, Cell, Grid, Ball, MovingBall } from "./config";
import { GRID_SIZE } from "./config";
import { createGrid } from "./helpers";

type State = {
  grid: Grid<Cell>;
  isGridEmpty: boolean;
  emptyCells: Coords[];
  nextBalls: Ball[];
  movingBall: MovingBall | null;
  activeCoords: Coords | null;
  score: number;
  isOver: boolean;
  isShaking: boolean;
  isAnimating: boolean;
};

export const state = createStore<State>({
  grid: createGrid(GRID_SIZE, null),
  nextBalls: [],
  movingBall: null,
  activeCoords: null,
  score: 0,
  isOver: false,
  isShaking: false,
  isAnimating: false,

  get isGridEmpty() {
    return this.grid.flat().filter(Boolean).length === 0;
  },

  get emptyCells() {
    const emptyList: Coords[] = [];
    this.grid.forEach((row, y) =>
      row.forEach((cell, x) => {
        if (cell === null) emptyList.push({ x, y });
      })
    );
    return emptyList;
  },
});

export const addScore = (value: number, $state = state) => {};

// restoreGame
// startGame
// moveBall
//
// setActiveCoords
// addScore
// gameOver
