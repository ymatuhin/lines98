import shuffle from "lodash/shuffle";
import { createStore } from "shared/store";
import { createStorage } from "shared/storage";
import { createLogger } from "shared/logger";
import { findPath } from "./path-finder";
import { findLines } from "./lines-finder";

import type { Coords, Cell, Grid, Ball } from "./config";
import { GRID_SIZE } from "./config";
import {
  checkGridHasNoBalls,
  createGrid,
  createThreeRandomBalls,
  getCellByCoords,
  getGridEmptyCellCoords,
  removeBalls,
  setCellByCoords,
  syncStoreWithStorage,
} from "./helpers";

const log = createLogger("👾 game");
const storage = createStorage<State>("state", { debug: log });

type State = {
  grid: Grid<Cell>;
  nextBalls: Ball[];
  movingBall: Coords | null;
  activeCoords: Coords | null;
  score: number;
  isOver: boolean;
  isShaking: boolean;
  isAnimating: boolean;
};

export const state = createStore<State>({
  grid: createGrid(GRID_SIZE, null),
  nextBalls: [],
  movingBall: null,
  activeCoords: null,
  score: 0,
  isOver: false,
  isShaking: false,
  isAnimating: false,
});

export function init() {
  log("init");
  syncStoreWithStorage(state, storage);
  state.subscribe((state) => log("state", { ...state }));

  if (state.nextBalls.length === 0) {
    state.nextBalls = createThreeRandomBalls();
  }

  if (checkGridHasNoBalls(state.grid)) {
    addBallsToGrid(createThreeRandomBalls());
  }
}

export function restart() {
  log("restart");
  state.score = 0;
  state.grid = createGrid(GRID_SIZE, null);
  state.nextBalls = createThreeRandomBalls();

  if (checkGridHasNoBalls(state.grid)) {
    addBallsToGrid(createThreeRandomBalls());
  }
}

export function nextTurn() {
  log("nextTurn");
  addBallsToGrid(state.nextBalls);
  checkLines();
}

export function handleCellClick(coords: Coords) {
  log("cellClick", coords);
  state.isShaking = false;

  if (getCellByCoords(state.grid, coords)) {
    state.activeCoords = coords;
  } else if (state.activeCoords) {
    const path = findPath(state.grid, state.activeCoords, coords);
    if (!path) return (state.isShaking = true);

    const activeCell = getCellByCoords(state.grid, state.activeCoords);
    setCellByCoords(state.grid, coords, activeCell);
    setCellByCoords(state.grid, state.activeCoords, null);
    state.activeCoords = null;

    const hadLines = checkLines();
    if (!hadLines) nextTurn();
  }
}

function animateStep(path: Coords[], color: Ball) {
  return new Promise<void>((res) => {
    if (path.length === 0) return res();
    state.movingBall = path.shift()!;
    setTimeout(() => animateStep(path), 200);
  });
}

function checkLines() {
  const lines = findLines(state.grid);
  log("checkLines", lines);

  if (lines.length) {
    removeBalls(state.grid, lines);
    state.score += lines.length * 2;
  }

  return Boolean(lines.length);
}

function gameOver() {
  log("gameOver");
}

function addBallsToGrid(balls: Ball[]) {
  log("addNextBallsToGrid", balls);
  const emptyCells = shuffle(getGridEmptyCellCoords(state.grid));

  for (const ball of balls) {
    const cell = emptyCells.shift();
    if (!cell) return gameOver();
    setCellByCoords(state.grid, cell, ball);
  }

  if (emptyCells.length === 0) return gameOver();
  state.nextBalls = createThreeRandomBalls();
}
