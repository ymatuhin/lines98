export type Coords = { x: number; y: number };
export type Cell = Ball | null;
export type Grid<T> = T[][];
export type Vector = [number, number];
export type Ball =
  | "aqua"
  | "blue"
  | "green"
  | "pink"
  | "red"
  | "violet"
  | "yellow";
export type MovingBall = Coords & { ball: Ball };

export const BALLS: Ball[] = [
  "aqua",
  "blue",
  "green",
  "pink",
  "red",
  "violet",
  "yellow",
];

export const GRID_SIZE = 9;
export const MIN_LINE_SIZE = 5;
