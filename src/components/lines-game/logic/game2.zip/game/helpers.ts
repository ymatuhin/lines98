import sample from "lodash/sample";

import type { Storage } from "shared/storage";
import { BALLS, type Cell, type Coords, type Grid } from "./config";
import type { Store } from "shared/store";

export function createGrid<T>(gridSize: number, item: T): T[][] {
  return Array(gridSize)
    .fill(item)
    .map((_) => Array(gridSize).fill(item));
}

export function getCellByCoords<T>(grid: Grid<T>, coords: Coords) {
  return grid[coords.y]?.[coords.x];
}

export function setCellByCoords<T>(grid: Grid<T>, coords: Coords, value: T) {
  grid[coords.y][coords.x] = value;
}

export function removeBalls<T>(grid: Grid<T>, coordsArr: Coords[]) {
  coordsArr.forEach((coords) => {
    setCellByCoords(grid, coords, null);
  });
}

export function checkGridHasNoBalls(grid: Grid<Cell>) {
  return grid.flat().filter(Boolean).length === 0;
}

export function getGridEmptyCellCoords(grid: Grid<Cell>) {
  const emptyList: Coords[] = [];
  grid.forEach((row, y) =>
    row.forEach((cell, x) => {
      if (cell === null) emptyList.push({ x, y });
    })
  );
  return emptyList;
}

export function syncStoreWithStorage<T extends Object>(
  store: Store<T>,
  storage: Storage<T>
) {
  const saved = storage.get() ?? {};
  Object.assign(store, saved);
  store.subscribe(storage.set);
}

export function createThreeRandomBalls() {
  return [sample(BALLS)!, sample(BALLS)!, sample(BALLS)!];
}
