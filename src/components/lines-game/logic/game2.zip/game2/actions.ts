import { action } from "shared/store";

// For public use
export const init = action();
export const start = action();
export const nextTurn = action();
export const clickCell = action();

// For private use
export const restore = action();
export const over = action();
export const addScore = action<[number]>();
export const save = action();
