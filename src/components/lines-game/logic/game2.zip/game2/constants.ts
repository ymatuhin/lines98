import type { Ball } from "./types";

export const BALLS: Ball[] = [
  "aqua",
  "blue",
  "green",
  "pink",
  "red",
  "violet",
  "yellow",
];

export const GRID_SIZE = 9;
export const MIN_LINE_SIZE = 5;
