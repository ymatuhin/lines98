export type Coords = { x: number; y: number };
export type Cell = Ball | null;
export type Grid<T> = T[][];
export type CellGrid = Grid<Cell>;
export type Vector = [number, number];
export type Ball =
  | "aqua"
  | "blue"
  | "green"
  | "pink"
  | "red"
  | "violet"
  | "yellow";
export type MovingBall = (Coords & { ball: Ball }) | null;
