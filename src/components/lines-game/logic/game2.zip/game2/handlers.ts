import { createStorage } from "shared/storage";
import { init, restore, save, start } from "./actions";
import { $grid, $isGridEmpty } from "./stores";
import { get } from "shared/store";
import type { CellGrid } from "./types";

const gridStorage = createStorage<CellGrid>("grid");

init.subscribe(() => {
  restore();
  if (get($isGridEmpty)) start();
});

$grid.on(restore, (grid) => gridStorage.get() ?? grid);
$grid.on(save, (grid) => gridStorage.set(grid));
