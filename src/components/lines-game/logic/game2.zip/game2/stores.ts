import { derived, writable } from "shared/store";
import { GRID_SIZE } from "./constants";
import { createGrid, getCellByCoords } from "./helpers";
import type { CellGrid, Coords, MovingBall } from "./types";

export const $grid = writable<CellGrid>(createGrid(GRID_SIZE, null));
export const $movingBall = writable<MovingBall>(null);
export const $activeCoords = writable<Coords | null>(null);
export const $nextBalls = writable<Coords[]>([]);

export const $score = writable(0);
export const $isOver = writable(false);
export const $isShaking = writable(false);

export const $activeBall = derived(
  [$grid, $activeCoords],
  ([grid, activeCoords]) =>
    activeCoords ? getCellByCoords(grid, activeCoords) : null
);

export const $isAnimating = derived($movingBall, (movingBall) =>
  Boolean(movingBall)
);

export const $hasActiveCoords = derived($activeCoords, (activeCoords) =>
  Boolean(activeCoords)
);

export const $isGridEmpty = derived(
  $grid,
  (grid) => grid.flat().filter(Boolean).length === 0
);

export const $emptyCells = derived($grid, (grid) => {
  const emptyList: Coords[] = [];
  grid.forEach((row, y) =>
    row.forEach((cell, x) => {
      if (cell === null) emptyList.push({ x, y });
    })
  );
  return emptyList;
});
