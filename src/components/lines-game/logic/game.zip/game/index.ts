export { default as Game } from "./game.svelte";
export * from "./game";
