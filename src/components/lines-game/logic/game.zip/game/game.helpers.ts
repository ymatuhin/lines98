import { gridSize, type Coords, type Grid } from "./game";

export function createGridWith(item: any = null) {
  return Array(gridSize)
    .fill(item)
    .map((_) => Array(gridSize).fill(item));
}

export function getCellByCoords<T>(grid: T[][], coords: Coords) {
  return grid[coords.y]?.[coords.x];
}

export function setGridCellByCoords<T>(
  grid: T[][],
  coords: Coords,
  value: any
) {
  grid[coords.y][coords.x] = value;
  return grid;
}
