import shuffle from "lodash/shuffle";
import { createStore } from "shared/store";
import { createStorage } from "shared/storage";
import { createLogger } from "shared/logger";
import { type Ball, createRandomBalls } from "./ball";
import { findPath } from "./path-finder";
import { findLines } from "./lines-finder";

export type Coords = { x: number; y: number };
export type Cell = Ball | null;
export type Grid = Cell[][];

const log = createLogger("👾 game");

type Store = {
  grid: Grid;
  nextBalls: Ball[];
  activeCoords: Coords | null;
  score: number;
  isOver: boolean;
  shakeBoard: boolean;
  animating: boolean;
};

export const gridSize = 9;
export const store = createStore<Store>({
  grid: createGrid(null),
  nextBalls: [],
  activeCoords: null,
  score: 0,
  isOver: false,
  shakeBoard: false,
  animating: false,
});

export function init() {
  log("init");
  persistState();
  logState();

  if (store.nextBalls.length === 0) {
    store.nextBalls = createRandomBalls(3);
  }

  if (checkGridHasNoBalls()) {
    addBallsToGrid(createRandomBalls(3));
  }
}

export function restart() {
  log("restart");
  store.score = 0;
  store.grid = createGrid(null);
  store.nextBalls = createRandomBalls(3);

  if (checkGridHasNoBalls()) {
    addBallsToGrid(createRandomBalls(3));
  }
}

export function nextTurn() {
  log("nextTurn");
  addBallsToGrid(store.nextBalls);
  checkLines();
}

export function handleCellClick(coords: Coords) {
  log("cellClick", coords);
  store.shakeBoard = false;

  if (getCell(coords)) {
    store.activeCoords = coords;
  } else if (store.activeCoords) {
    const path = findPath(store.grid, store.activeCoords, coords);
    if (!path) return (store.shakeBoard = true);

    setCell(coords, getCell(store.activeCoords));
    setCell(store.activeCoords, null);
    store.activeCoords = null;

    const hadLines = checkLines();
    if (!hadLines) nextTurn();
  }
}

function checkLines() {
  const lines = findLines(store.grid);
  log("checkLines", lines);

  if (lines.length) {
    removeBalls(lines);
    store.score += lines.length * 2;
  }

  return Boolean(lines.length);
}

function gameOver() {
  console.info(`🔥 gameOver (game.ts)`);
}

function persistState() {
  const storage = createStorage<Store>("state");
  const saved = storage.get() ?? {};
  Object.assign(store, saved);
  store.subscribe(storage.set);
}

function logState() {
  store.subscribe((state) => log("state", state));
}

function createGrid(item: any = null) {
  return Array(gridSize)
    .fill(item)
    .map((_) => Array(gridSize).fill(item));
}

function checkGridHasNoBalls() {
  return store.grid.flat().filter(Boolean).length === 0;
}

function getGridEmptyCellCoords() {
  const emptyList: Coords[] = [];
  store.grid.forEach((row, y) =>
    row.forEach((cell, x) => {
      if (cell === null) emptyList.push({ x, y });
    })
  );
  return emptyList;
}

function addBallsToGrid(balls: Ball[]) {
  const colors = balls.map(({ color }) => color);
  log("addNextBallsToGrid", colors);
  const emptyCells = shuffle(getGridEmptyCellCoords());

  for (const ball of balls) {
    const cell = emptyCells.shift();
    if (!cell) return gameOver();
    setCell(cell, ball);
  }

  if (emptyCells.length === 0) return gameOver();
  store.nextBalls = createRandomBalls(3);
}

function setCell({ x, y }: Coords, cell: Cell) {
  store.grid[y][x] = cell;
}

function getCell({ x, y }: Coords) {
  return store.grid[y]?.[x];
}

function removeBalls(coordsArr: Coords[]) {
  coordsArr.forEach((coords) => {
    setCell(coords, null);
  });
}
