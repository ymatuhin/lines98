import { gridSize, type Coords, type Grid } from "../game";
import { findLine } from "./find-line";

export function findVerticalLines(grid: Grid, minLineSize: number) {
  const lines: Coords[] = [];

  console.info(`🔥 findVerticalLines (find-vertical-lines.ts)`);
  for (let x = 0; x < gridSize; x++) {
    const line = findLine(grid, { x, y: 0 }, [0, 1], minLineSize);
    if (line) lines.push(...line);
  }

  return lines;
}
