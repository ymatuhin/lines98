import { gridSize, type Coords, type Grid } from "../game";
import { findLine } from "./find-line";

export function findDiagonalFallingLines(grid: Grid, minLineSize: number) {
  const lines: Coords[] = [];

  let y = gridSize - minLineSize;
  let x = 0;

  console.info(`🔥 findDiagonalFallingLines (find-diagonal-falling-lines.ts)`);

  for (; y > 0; y--) {
    const line = findLine(grid, { x, y }, [1, 1], minLineSize);
    if (line) lines.push(...line);
  }

  for (; x < minLineSize; x++) {
    const line = findLine(grid, { x, y }, [1, 1], minLineSize);
    if (line) lines.push(...line);
  }

  return lines;
}
