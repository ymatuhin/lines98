import { gridSize, type Coords, type Grid } from "../game";
import { findLine } from "./find-line";

export function findHorizontalLines(grid: Grid, minLineSize: number) {
  const lines: Coords[] = [];

  console.info(`🔥 findHorizontalLines (find-horizontal-lines.ts)`);
  for (let y = 0; y < gridSize; y++) {
    const line = findLine(grid, { x: 0, y }, [1, 0], minLineSize);
    if (line) lines.push(...line);
  }

  return lines;
}
