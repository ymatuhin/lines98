import { gridSize, type Coords, type Grid, Cell } from "../game";

export type Vector = [number, number];

export function findLine(
  grid: Grid,
  startCoords: Coords,
  vector: Vector,
  lineSize: number
) {
  const fullLine = getFullLine(startCoords, vector);

  let line: Coords[] = [];
  let prevCoords: Coords | null = null;
  for (const coords of fullLine) {
    const prevCell = prevCoords ? grid[prevCoords.y][prevCoords.x] : null;
    const cell = grid[coords.y][coords.x];

    if (!cell) {
      if (line.length >= lineSize) break;
      line = [];
    } else if (!prevCell || cell.color !== prevCell.color) {
      if (line.length >= lineSize) break;
      line = [coords];
    } else if (cell.color === prevCell.color) {
      line.push(coords);
    }

    prevCoords = coords;
  }

  return line.length >= lineSize ? line : null;
}

export function getFullLine(startCoords: Coords, vector: Vector) {
  const fullLine: Coords[] = [];

  for (
    let x = startCoords.x, y = startCoords.y;
    x < gridSize && x >= 0 && y >= 0 && y < gridSize;
    x += vector[0], y += vector[1]
  ) {
    fullLine.push({ x, y });
  }

  return fullLine;
}
